import React from 'react'


import fallintotravelpic1 from '/public/chitral.jpg'
import fallintotravelpic2 from '/public/skardu.jpg'
import fallintotravelpic3 from '/public/swat.jpg'
import fallintotravelpic4 from '/public/Attabad.jpg'
const FallIntoTravel = () => {
  return (
    <div className=" mx-[70px]  mt-10">
    <p className="h-9 self-stretch text-[32px] font-bold mb-7 text-primarycolor ">Fall into travel</p>
<p className="mt-[16px] max-w-[800px] leading-7 mb-4 text-secondarycolor font-bold "> Going somewhere to celebrate this season? Whether you’re going home or somewhere to roam, we’ve got the travel tools to get you to your destination.</p>
<div className="flex flex-col md:flex-row md:gap-x-10 gap-y-6 mt-[25px]">
<div>
<img src={fallintotravelpic1} alt='travel img' className="w-[270px] h-[350px] object-cover rounded-xl bg-blur"/>
<p className="text-white text-[24px] -mt-10 ml-2 font-extrabold backdrop-brightness-50 rounded-lg ">5 day trip to Chitral</p>
<button className="flex h-12 justify-center items-center gap-1 self-stretch rounded px-4 py-2 bg-secondarycolor text-white mt-4 ">Book Tour</button>
</div>
<div>
<img src={fallintotravelpic2} alt='travel img' className="w-[270px] h-[350px] object-cover rounded-xl"/>
<p className="text-white text-[24px] -mt-10 ml-2 font-extrabold backdrop-brightness-50 ">7 day trip to Skardu</p>
<button className="flex h-12 justify-center items-center gap-1 self-stretch rounded px-4 py-2 bg-secondarycolor text-white mt-4">Book Tour</button>

</div>
<div>
<img src={fallintotravelpic3} alt='travel img' className="w-[270px] h-[350px] object-cover rounded-xl"/>
<p className="text-white text-[24px] -mt-10 ml-2 font-extrabold backdrop-brightness-50 ">3 day trip to Swat</p>
<button className="flex h-12 justify-center items-center gap-1 self-stretch rounded px-4 py-2 bg-secondarycolor text-white mt-4">Book Tour</button>

</div>
<div>
<img src={fallintotravelpic4} alt='travel img' className="w-[270px] h-[350px] object-cover rounded-xl"/>
<p className="text-white text-[24px] -mt-10 ml-2 font-extrabold backdrop-brightness-50">2 day trip to Attabad</p>
<button className="flex h-12 justify-center items-center gap-1 self-stretch rounded px-4 py-2 bg-secondarycolor text-white mt-4">Book Tour</button>

</div>


</div>


  </div>
  )
}

export default FallIntoTravel