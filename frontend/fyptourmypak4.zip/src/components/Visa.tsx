'use client'
import React from 'react';
// import { Box, Typography, Grid, Paper } from '@mui/material';
// import { TextField } from '@mui/material';
// import { FlightTakeoff, FlightLand, CalendarToday, People } from '@mui/icons-material';
const Visa = () => {
 

  return (

   <div>
    Visa
{/*  
  <Box
      display="flex"
      p={3}
      boxShadow={3}
      borderRadius={8}
    >
      <div className=' flex flex-col md:flex-row gap-2' style={{ width: '100%' }}>
      <TextField
        label="Country"
        placeholder="Country Name"
        variant="outlined"
        fullWidth
        InputProps={{
          startAdornment: <FlightTakeoff />,
        }}
        sx={{ marginBottom: 2 }}
      />
    
      <TextField
        label="Issue Date"
        type="date"
        variant="outlined"
        fullWidth
        InputProps={{
          startAdornment: <CalendarToday />,
        }}
        sx={{ marginBottom: 2 }}
      />
       <TextField
        label="Expiry Date"
        type="date"
        variant="outlined"
        fullWidth
        InputProps={{
          startAdornment: <CalendarToday />,
        }}
        sx={{ marginBottom: 2 }}
      />
    
     </div>
    </Box> */}

</div>

  );
};

export default Visa;
