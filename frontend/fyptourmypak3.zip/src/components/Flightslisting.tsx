
import React from "react";
import "./SearchPage.css";
import SearchResult from "./SearchResult";
import skardu from '/skardu.jpg'
function SearchPage() {
  return (
    <div className="searchPage">
      <div className="searchPage__info">
   

        <button className="border rounded-xl p-2 bg-secondarycolor text-white hover:bg-primarycolor" >Recommended</button>
        <button className="border rounded-xl p-2 bg-secondarycolor text-white hover:bg-primarycolor" >High rated</button>
        <button className="border rounded-xl p-2 bg-secondarycolor text-white hover:bg-primarycolor">Low Price</button>

      </div>
      <SearchResult
        img={skardu}
        location="Islamabad to Skardu"
        title="2 days Skardu trip"
        description=".bornfire .hitea"
        star={4.73}
        price="PKR 10,000 per person"
        total=""
      />
      <SearchResult
        img={skardu}
        location="Islamabad to Skardu"
        title="2 days Skardu trip"
        description=".bornfire .hitea"
        star={4.73}
        price="PKR 10,000 per person"
        total=""
      />
      <SearchResult
        img={skardu}
        location="Islamabad to Skardu"
        title="2 days Skardu trip"
        description=".bornfire .hitea"
        star={4.73}
        price="PKR 10,000 per person"
        total=""
      />
      <SearchResult
        img={skardu}
        location="Islamabad to Skardu"
        title="2 days Skardu trip"
        description=".bornfire .hitea"
        star={4.73}
        price="PKR 10,000 per person"
        total=""
      />
      <SearchResult
        img={skardu}
        location="Islamabad to Skardu"
        title="2 days Skardu trip"
        description=".bornfire .hitea"
        star={4.73}
        price="PKR 10,000 per person"
        total=""
      />
      <SearchResult
        img={skardu}
        location="Islamabad to Skardu"
        title="2 days Skardu trip"
        description=".bornfire .hitea"
        star={4.73}
        price="PKR 10,000 per person"
        total=""
      />
      <SearchResult
        img={skardu}
        location="Islamabad to Skardu"
        title="2 days Skardu trip"
        description=".bornfire .hitea"
        star={4.73}
        price="PKR 10,000 per person"
        total=""
      />
     
    </div>
  );
}

export default SearchPage;
