import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";
 import StateContext from './components/StateContext'
 import { ConfigProvider } from 'antd';
import theme from './theme/themeConfig';
import Home from './components/Home'
import Flightslisting from "./components/Flightslisting";
import Header from "./components/layout/Header";
import MyFooter from "./components/MyFooter";
import Hotelslisting from "./components/Hotelslisting";
import Carslisting from "./components/Carslisting";

function App() {
  return (
    <Router>
          <Header/>
    <StateContext>
    <ConfigProvider theme={theme}>
    </ConfigProvider>
      <Routes>
                        <Route
                            
                            path="/"
                            element={<Home />}
                        ></Route>
                        <Route
                            
                            path="/flightslisting"
                            element={<Flightslisting />}
                        ></Route>
                        <Route
                            
                            path="/hotelslisting"
                            element={<Hotelslisting />}
                        ></Route>
                        <Route
                            
                            path="/carslisting"
                            element={<Carslisting />}
                        ></Route>
                      
                    </Routes>
                   
    <ConfigProvider/>
    </StateContext>
    <MyFooter/>
    </Router>
  );
}

export default App;
