import React from "react";
// import Header from "../components/layout/Header";
import FlightForm from "./FlightForm";
import RecentSearches from "./RecentSearches";
import FallIntoTravel from "./FallIntoTravel";
// import MyFooter from "./MyFooter";
import mainimage from '../../public/main5.jpg'

function Home() {
  return (
   
 
    <div className="">
      {/* <Header/> */}
     <div className="">
        <div className=" ">
         <img src={mainimage} alt="Heroposter" className=" w-full h-[600px] object-cover"/>
         </div>
     
      <div className=" absolute top-[200px] ">
        <FlightForm />
      </div>
 
      </div>
     
      <RecentSearches />
      <FallIntoTravel />
      {/* <MyFooter /> */}
 
      
    </div>
   
   
  );
}

export default Home;
